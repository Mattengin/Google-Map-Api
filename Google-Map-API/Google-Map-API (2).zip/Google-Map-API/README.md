# Google Map API

A Google Map api centering on Birmingham.

## How it works?

Uses API key from Google to make a Google map.
tap one of the premade buttons for some info.
 use the search bar to find a place.

#### Wikipedia API

By useing wiki 3rd party application to provide you with Street View.

## How can I use this?

Download the zip file and load it on your text editor that supports Javascript, HTML, and CSS.
Note: you may have to unzip the file to make all content appear.

### Resources

(https://www.mediawiki.org/wiki/API:Main_page)
(https://developers.google.com/maps/documentation/javascript/streetview)
(https://developers.google.com/maps/documentation/)
(http://knockoutjs.com/documentation/binding-syntax.html)